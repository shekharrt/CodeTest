﻿using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Interactions;
using System;
using TechTalk.SpecFlow;

namespace LinkGroup.DemoTests
{
    [Binding]
    public class LinkGroupSteps
    {
        IWebDriver driver;
        [Given(@"I have opened the home page")]
        public void GivenIHaveOpenedTheHomePage()
        {
            driver = new ChromeDriver();
            driver.Url = "https://www.linkgroup.eu/";
        }
        
        [Given(@"I have agreed to the cookie policy")]
        public void GivenIHaveAgreedToTheCookiePolicy()
        {
            IWebElement alert= driver.FindElement(By.XPath("//a[contains(text(),'Agree')] "));
            //Click on Agree
            alert.Click();
        }

        [When(@"I search for '(.*)' Then the search results are displayed")]
        public void WhenISearchForThenTheSearchResultsAreDisplayed(string SearchString)
        {
            Actions actions = new Actions(driver);
            //mouse hover action
            IWebElement menuOption = driver.FindElement(By.XPath("//a//i[@class='fa fa-search']"));
            actions.MoveToElement(menuOption).Perform();
            //Input the string in search field
            driver.FindElement(By.XPath("//input[@name='searchTerm']']")).SendKeys(SearchString);
            //Click on Search
            driver.FindElement(By.XPath("//button[contains(text(),'Search')]")).Click();
            //Verify for Search Result
            true.Equals(driver.FindElement(By.XPath("//h3[contains(text(),'You searched for: ')]")).Displayed);
        }

        [When(@"I open the home page")]
        public void WhenIOpenTheHomePage()
        {
            driver = new ChromeDriver();
            driver.Url = "https://www.linkgroup.eu/";
        }

        [Then(@"the page is displayed")]
        public void ThePageIsDisplayed()
        {
            //verify LINkGroup on HomePage to assert Home Page
            true.Equals(driver.Title.Contains("Home"));
            true.Equals(driver.FindElement(By.XPath("(//img[@src='/media/1214/link-group-logo-rgb-rev-orange.png'])[1]")).Displayed);
        }

    }
}
