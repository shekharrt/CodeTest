﻿using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using System;
using TechTalk.SpecFlow;

namespace LinkGroup.DemoTests
{
    [Binding]
    public class LinkFundSolutionsSteps
    {
        IWebDriver driver;
        [When(@"I open the Found Solutions page")]
        public void WhenIOpenTheFoundSolutionsPage()
        {
            driver = new ChromeDriver();
            driver.Url = "https://www.linkfundsolutions.co.uk/";
        }
        
        [Then(@"I can select the '(.*)’  jurisdiction")]
        public void ThenICanSelectTheUnitedKingdomJurisdiction(String country)
        {
            driver.FindElement(By.XPath("//a[contains(text(),'United Kingdom')]")).Click();
        }
    }
}
